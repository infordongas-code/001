# Projeto de Vida — Carlos (Doutor) & Cleidson (Empresário)

Site interativo desenvolvido em **HTML5**, **CSS3** e **JavaScript** para apresentação e acompanhamento do Projeto de Vida de **Carlos (Medicina)** e **Cleidson (Empreendedorismo)**.

## Estrutura de Pastas

- `index.html`: Estrutura principal da página, perfis de trajetória, tabela dos 3 pilares e planejador de metas.
- `css/style.css`: Estilização responsiva e layout otimizado para impressão em PDF.
- `js/script.js`: Cadastro de metas, filtros por integrante, marcação de etapas concluídas e salvamento automático no `localStorage`.
- `.vscode/settings.json`: Configurações recomendadas para o Visual Studio Code.

## Como abrir no Visual Studio Code (VS Code)

1. Extraia o arquivo `.zip` em uma pasta no seu computador.
2. Abra o **VS Code**, clique em **Arquivo > Abrir Pasta...** e selecione a pasta extraída.
3. Abra o arquivo `index.html` diretamente no navegador ou utilize a extensão **Live Server** clicando em **Go Live** no canto inferior direito.
