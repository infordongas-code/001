const STORAGE_KEY = "projeto_vida_carlos_cleidson_v1";

const metasIniciais = [
  {
    id: 1,
    responsavel: "Carlos",
    titulo: "Conquistar aprovação na faculdade de Medicina",
    prazo: "Curto Prazo",
    passo: "Manter rotina diária de simulados e revisão de Ciências da Natureza",
    concluida: false
  },
  {
    id: 2,
    responsavel: "Cleidson",
    titulo: "Estruturar plano de negócios e capital inicial da empresa",
    prazo: "Curto Prazo",
    passo: "Mapear oportunidades do mercado local e estudar gestão financeira",
    concluida: false
  },
  {
    id: 3,
    responsavel: "Carlos",
    titulo: "Concluir graduação em Medicina e iniciar residência médica",
    prazo: "Longo Prazo",
    passo: "Participar de ligas acadêmicas e estágios hospitalares",
    concluida: false
  },
  {
    id: 4,
    responsavel: "Cleidson",
    titulo: "Expandir a empresa e gerar novos postos de trabalho",
    prazo: "Médio Prazo",
    passo: "Consolidar processos internos e atendimento de excelência",
    concluida: false
  },
  {
    id: 5,
    responsavel: "Ambos",
    titulo: "Promover ações sociais e projetos de impacto na comunidade",
    prazo: "Longo Prazo",
    passo: "Unir saúde preventiva e empreendedorismo social",
    concluida: false
  }
];

let metas = carregarMetas();
let filtroAtual = "Todas";

const formMeta = document.getElementById("form-meta");
const listaMetasEl = document.getElementById("lista-metas");
const totalMetasEl = document.getElementById("total-metas");
const metasConcluidasEl = document.getElementById("metas-concluidas");
const percentualConcluidoEl = document.getElementById("percentual-concluido");
const filterBtns = document.querySelectorAll(".filter-btn");
const btnImprimir = document.getElementById("btn-imprimir");

function carregarMetas() {
  const salvo = localStorage.getItem(STORAGE_KEY);
  if (salvo) {
    try {
      return JSON.parse(salvo);
    } catch (e) {
      return [...metasIniciais];
    }
  }
  return [...metasIniciais];
}

function salvarMetas() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(metas));
}

function atualizarIndicadores() {
  const total = metas.length;
  const concluidas = metas.filter((m) => m.concluida).length;
  const percentual = total > 0 ? Math.round((concluidas / total) * 100) : 0;

  totalMetasEl.textContent = total;
  metasConcluidasEl.textContent = concluidas;
  percentualConcluidoEl.textContent = `${percentual}% de avanço`;
}

function renderizarMetas() {
  const filtradas = filtroAtual === "Todas"
    ? metas
    : metas.filter((m) => m.responsavel === filtroAtual);

  if (filtradas.length === 0) {
    listaMetasEl.innerHTML = `
      <div class="empty-state">
        Nenhuma meta encontrada para este filtro. Cadastre uma nova meta ao lado.
      </div>
    `;
    atualizarIndicadores();
    return;
  }

  listaMetasEl.innerHTML = filtradas.map((meta) => {
    const rotuloPessoa = meta.responsavel === "Ambos"
      ? "Carlos & Cleidson"
      : meta.responsavel;

    return `
      <article class="goal-item ${meta.concluida ? "done" : ""}">
        <div>
          <div class="goal-badges">
            <span class="pill pill-${meta.responsavel}">${rotuloPessoa}</span>
            <span class="pill pill-prazo">${meta.prazo}</span>
          </div>
          <h4 class="goal-title">${escapeHtml(meta.titulo)}</h4>
          <p class="goal-step"><strong>Primeiro passo:</strong> ${escapeHtml(meta.passo)}</p>
        </div>
        <div class="goal-actions">
          <button
            type="button"
            class="btn-small btn-check ${meta.concluida ? "completed" : ""}"
            onclick="alternarConclusao(${meta.id})"
          >
            ${meta.concluida ? "Concluída" : "Concluir"}
          </button>
          <button
            type="button"
            class="btn-small btn-delete"
            onclick="removerMeta(${meta.id})"
            aria-label="Excluir meta"
          >
            Excluir
          </button>
        </div>
      </article>
    `;
  }).join("");

  atualizarIndicadores();
}

function escapeHtml(texto) {
  const div = document.createElement("div");
  div.textContent = texto;
  return div.innerHTML;
}

window.alternarConclusao = function (id) {
  metas = metas.map((meta) =>
    meta.id === id ? { ...meta, concluida: !meta.concluida } : meta
  );
  salvarMetas();
  renderizarMetas();
};

window.removerMeta = function (id) {
  metas = metas.filter((meta) => meta.id !== id);
  salvarMetas();
  renderizarMetas();
};

formMeta.addEventListener("submit", (event) => {
  event.preventDefault();

  const responsavel = document.getElementById("responsavel").value;
  const titulo = document.getElementById("titulo").value.trim();
  const prazo = document.getElementById("prazo").value;
  const passo = document.getElementById("passo").value.trim();

  if (!titulo || !passo) return;

  const novaMeta = {
    id: Date.now(),
    responsavel,
    titulo,
    prazo,
    passo,
    concluida: false
  };

  metas.unshift(novaMeta);
  salvarMetas();
  formMeta.reset();
  renderizarMetas();
});

filterBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    filterBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    filtroAtual = btn.dataset.filter;
    renderizarMetas();
  });
});

btnImprimir.addEventListener("click", () => {
  window.print();
});

renderizarMetas();
